
Globals
=======

.. autofunction:: av.open
